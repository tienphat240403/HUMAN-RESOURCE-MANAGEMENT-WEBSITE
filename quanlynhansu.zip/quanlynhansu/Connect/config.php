<?php
// Thay thế các thông tin kết nối của bạn vào dòng sau
$host = 'localhost';
$dbname = 'ql';
$username = 'root';
$password = '';

try {
    // Tạo kết nối PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);

    // Thiết lập chế độ thông báo lỗi
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Kết nối không thành công: " . $e->getMessage());
}