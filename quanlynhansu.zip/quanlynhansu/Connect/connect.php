<?php
include 'config.php';

try {
    $conn = new PDO('mysql:host=localhost;dbname='.$dbname, $username, $password);
    $conn->query('set names utf8');
} catch(PDOException $e) {
    echo 'Err';
    exit;
}
