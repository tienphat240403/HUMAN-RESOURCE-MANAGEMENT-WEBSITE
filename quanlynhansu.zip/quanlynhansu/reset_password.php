<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kết nối đến cơ sở dữ liệu và xử lý reset mật khẩu
    // Code kết nối cơ sở dữ liệu và xử lý reset mật khẩu ở đây

    // Lấy email từ form
    $email = $_POST["email"];

    // Kiểm tra xem email có tồn tại trong cơ sở dữ liệu hay không
    // Nếu email tồn tại, thực hiện reset mật khẩu và gửi mật khẩu mới đến email
    // Nếu không, hiển thị thông báo lỗi

    // Tạo mật khẩu ngẫu nhiên
    $newPassword = generateRandomPassword();

    // Cập nhật mật khẩu mới vào cơ sở dữ liệu (ví dụ: bảng người dùng)
    // Code cập nhật mật khẩu mới vào cơ sở dữ liệu ở đây

    // Gửi mật khẩu mới qua email
    $subject = "Password Reset";
    $message = "Your new password is: " . $newPassword;
    $headers = "From: nguyenphat240403@gmail.com";

    // Gửi email
    if (mail($email, $subject, $message, $headers)) {
        echo "A new password has been sent to your email.";
    } else {
        echo "Failed to send a new password. Please try again later.";
    }
}

function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

