<?php
//include 'config.php';

if (isset($_POST['MaNV'])) {
    $MaNV = $_POST['MaNV'];
    $sql = "DELETE FROM thongtinnhanvien WHERE MaNV = '$MaNV'";
    if ($conn->query($sql) === TRUE) {
        echo "Nhân viên đã được xóa thành công";
    } else {
        echo "Lỗi khi xóa nhân viên: " . $conn->error;
    }
}
$conn->close();

