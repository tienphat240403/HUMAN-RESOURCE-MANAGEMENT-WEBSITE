<?php
$servername = "localhost"; // Change this to your database server
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "ql"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $MaNV = $_POST['MaNV'];
    $Hoten = $_POST['Hoten'];
    $Email = $_POST['Email'];
    $Nguyenquan = $_POST['Nguyenquan'];
    $Sodienthoai = $_POST['Sodienthoai'];
    $Ngaysinh = $_POST['Ngaysinh'];
    $Noisinh = $_POST['Noisinh'];
    $CMND = $_POST['CMND'];
    $Ngaycap = $_POST['Ngaycap'];
    $Noicap = $_POST['Noicap'];
    $Gioitinh = $_POST['Gioitinh'];
    $Chucvu = $_POST['Chucvu'];
    $Bangcap = $_POST['Bangcap'];
    $Tinhtranghonnhan = $_POST['Tinhtranghonnhan'];

    // Handle file upload
    if (isset($_FILES['Anh']) && $_FILES['Anh']['error'] == 0) {
        $Anh = $_FILES['Anh'];
        $imagePath = "uploads/" . basename($Anh["name"]);
        move_uploaded_file($Anh["tmp_name"], $imagePath);
    } else {
        $imagePath = null;
    }

    $sql = "INSERT INTO thongtinnhanvien (MaNV, Hoten, Anh, Ngaysinh, Noisinh, Nguyenquan, Gioitinh, Email, Tinhtranghonnhan, Chucvu, Bangcap, CMND, Ngaycap, Noicap, Sodienthoai)
            VALUES ('$MaNV', '$Hoten', '$imagePath', '$Ngaysinh', '$Noisinh', '$Nguyenquan', '$Gioitinh', '$Email', '$Tinhtranghonnhan', '$Chucvu', '$Bangcap', '$CMND', '$Ngaycap', '$Noicap', '$Sodienthoai')";

    if ($conn->query($sql) === TRUE) {
        echo "New employee created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
