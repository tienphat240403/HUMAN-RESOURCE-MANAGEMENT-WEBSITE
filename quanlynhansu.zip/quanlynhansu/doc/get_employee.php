<?php
//include 'config.php';

if (isset($_GET['MaNV'])) {
    $MaNV = $_GET['MaNV'];
    $sql = "SELECT * FROM thongtinnhanvien WHERE MaNV = '$MaNV'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode($result->fetch_assoc());
    } else {
        echo "Không tìm thấy nhân viên";
    }
}
$conn->close();
