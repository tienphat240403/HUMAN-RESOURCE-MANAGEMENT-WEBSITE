<?php
//include 'config.php';

if (isset($_POST['MaNV'])) {
    $MaNV = $_POST['MaNV'];
    $Hoten = $_POST['Hoten'];
    $Noisinh = $_POST['Noisinh'];
    $Email = $_POST['Email'];
    $Ngaysinh = $_POST['Ngaysinh'];
    $Chucvu = $_POST['Chucvu'];

    $sql = "UPDATE thongtinnhanvien SET Hoten='$Hoten', Noisinh='$Noisinh', Email='$Email', Ngaysinh='$Ngaysinh', Chucvu='$TenCV' WHERE MaNV='$MaNV'";

    if ($conn->query($sql) === TRUE) {
        echo "Thông tin nhân viên đã được cập nhật thành công";
    } else {
        echo "Lỗi khi cập nhật thông tin nhân viên: " . $conn->error;
    }
}
$conn->close();

