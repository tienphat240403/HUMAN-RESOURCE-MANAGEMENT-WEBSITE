-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `ql`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chucvu`
--

CREATE TABLE `chucvu` (
  `MaNV` char(5) NOT NULL,
  `MaPB` char(5) NOT NULL,
  `TenPB` varchar(20) NOT NULL,
  `MaCV` char(5) NOT NULL,
  `TenCV` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `chucvu`
--

INSERT INTO `chucvu` (`MaNV`, `MaPB`, `TenPB`, `MaCV`, `TenCV`) VALUES
('nv01', 'HT', 'VP Hiệu Trưởng', '1', 'Hiệu Trưởng'),
('nv02', 'HT', 'VP Hiệu Trưởng', '2', 'Phó Hiệu trưởng'),
('nv03', 'HC', 'Phòng hành chính', '3', 'Trưởng phòng'),
('nv04', 'HC', 'Phòng hành chính', '4', 'Phó phòng'),
('nv05', 'HC', 'Phòng hành chính', '5', 'Nhân viên'),
('nv06', 'KD', 'Phòng kinh doanh', '3', 'Trưởng phòng'),
('nv07', 'KD', 'Phòng kinh doanh', '4', 'Phó phòng'),
('nv08', 'KD', 'Phòng kinh doanh', '5', 'Nhân viên'),
('nv09', 'KT', 'Phòng kế toán', '3', 'Trưởng phòng'),
('nv10', 'KT', 'Phòng kế toán', '4', 'Phó phòng'),
('nv10', 'KT', 'Phòng kế toán', '5', 'Nhân viên'),
('nv11', 'VPGV', 'VP Giáo Viên', '6', 'Tổ trưởng'),
('nv12', 'VPGV', 'VP Giáo Viên', '7', 'Tổ phó'),
('nv13', 'VPGV', 'VP Giáo Viên', '8', 'Giáo Viên'),
('nv14', 'VPGV', 'VP Giáo Viên', '8', 'Giáo Viên'),
('nv15', 'VPGV', 'VP Giáo Viên', '8', 'Giáo Viên'),
('nv16', 'VPGV', 'VP Giáo Viên', '8', 'Giáo Viên'),
('nv17', 'VPGV', 'VP Giáo Viên', '8', 'Giáo Viên'),
('nv18', 'VPGV', 'VP Giáo Viên', '8', 'Giáo Viên'),
('nv19', 'BV', 'Phòng bảo vệ', '9', 'Bảo vệ'),
('nv20', 'BV', 'Phòng bảo vệ', '9', 'Bảo vệ'),
('nv21', 'NS', 'Nhân sự', '3', 'Trưởng phòng'),
('nv22', 'NS', 'Nhân sự', '4', 'Phó phòng'),

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `thongtinnhanvien`
--

CREATE TABLE `thongtinnhanvien` (
  `MaNV` char(5) NOT NULL,
  `Hoten` text NOT NULL,
  `Ngaysinh` date DEFAULT NULL,
  `Noisinh` text DEFAULT NULL,
  `Nguyenquan` text DEFAULT NULL,
  `Gioitinh` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `Email` text NOT NULL,
  `Tinhtranghonnhan` text DEFAULT NULL,
  `Tinhtrangsuckhoe` text DEFAULT NULL,
  `Anh` char(100) DEFAULT NULL,
  `Thaotac` varchar(10) CHARACTER SET utf16 COLLATE utf16_unicode_520_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `thongtinnhanvien`
--

INSERT INTO `thongtinnhanvien` (`MaNV`, `Hoten`, `Ngaysinh`, `Noisinh`, `Nguyenquan`, `Gioitinh`, `Email`, `Tinhtranghonnhan`, `Tinhtrangsuckhoe`, `Anh`, `Thaotac`) VALUES
('nv01', 'Nguyễn Tuấn Anh', '1997-11-20', 'TP.HCM', 'TP.HCM', 'Nam', 'tuananhnguyen97@gmail.com', 'Chưa', 'Tốt', 'anh/nv01.jpg', ''),
('nv02', 'Trần Thị Thu Hằng', '1988-03-06', 'Ninh Bình', 'Ninh Bình', 'Nữ', '', 'Chưa', 'Tốt', 'anh/nv08.jpg', ''),
('nv03', 'Lê Hồng Phúc', '1988-06-21', 'Hà Nội', 'Hà Nội', 'Nữ', '', 'Chưa', 'Tốt', 'anh/nv10.jpg', ''),
('nv04', 'Nguyễn Thu Huyền', '1989-12-07', 'Quản Ninh', 'Quảng Ninh', 'Nữ', '', 'Chưa', 'Tốt', 'anh/nv11.jpg', ''),
('nv05', 'Nguyễn Hòa Bình', '1986-04-09', 'Thái Bình', 'Thái Bình', '', '0', 'Chưa', 'Tốt', 'anh/nv03.jpg', ''),
('nv06', 'Đào Văn Ánh', '1987-06-21', 'Thanh Hóa', 'Thanh Hóa', '', '0', 'Chưa', 'Tốt', 'anh/nv12.jpg', ''),
('nv07', 'Chu Anh Tiến', '1988-06-17', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv06.jpg', ''),
('nv08', 'Hoàng Thị Nguyệt', '1988-07-22', 'Hưng Yên', 'Hưng Yên', '', '0', 'Chưa', 'Tốt', 'anh/nv13.jpg', ''),
('nv09', 'Bùi Trọng Đạt', '1988-10-18', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv07.jpg', ''),
('nv10', 'Ninh Thị Huyền Trang', '1987-10-01', 'Hải Dương', 'Hải Dương', '', '0', 'Chưa', 'Tốt', 'anh/nv14.jpg', ''),
('nv11', 'Vũ Quốc Huy', '1988-08-26', 'Hưng Yên', 'Hưng Yên', '', '0', 'Chưa', 'Tốt', 'anh/nv09.jpg', ''),
('nv12', 'Lưu Tuấn Anh', '1986-06-09', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv15.jpg', ''),
('nv13', 'Trần Ngọc Anh', '1987-04-20', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv17.jpg', ''),
('nv14', 'Nguyễn Diệu Hương', '1988-10-15', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv18.jpg', ''),
('nv15', 'Hoàng Thị Thương', '1988-03-03', 'Hưng Yên', 'Hưng Yên', '', '0', 'Chưa', 'Tốt', 'anh/nv19.jpg', ''),
('nv16', 'Lê Thùy Dung', '1988-11-15', 'Bắc Ninh', 'Bắc Ninh', '', '0', 'Chưa', 'Tốt', 'anh/nv21.jpg', ''),
('nv17', 'Nguyễn Ngọc Linh', '1987-07-16', 'Bắc Ninh', 'Bắc Ninh', '', '0', 'Chưa', 'Tốt', 'anh/nv20.jpg', ''),
('nv18', 'Nguyễn Nhật Thành', '1988-08-24', 'Điện Biên Phủ', 'Điện Biên Phủ', '', '0', 'Chưa', 'Tốt', 'anh/nv16.jpg', ''),
('nv19', 'Lê Việt Anh', '1987-04-13', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv22.jpg', ''),
('nv20', 'Việt Khương', '1988-12-29', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv02.jpg', ''),
('nv21', 'Đỗ Kim Ngọc', '1988-08-02', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv04.jpg', ''),
('nv22', 'Lưu Thị Hà Như', '1988-01-18', 'Hà Nội', 'Hà Nội', '', '0', 'Chưa', 'Tốt', 'anh/nv05.jpg', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `MaNV` char(5) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `quyen` int(2) NOT NULL,
  `ghichu` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`MaNV`, `username`, `password`, `quyen`, `ghichu`) VALUES
('nv01', 'tuananh', '12345', 1, 'Admin'),
('nv02', 'thuhang', '12345', 1, NULL),
('nv21', 'tienthang', '12345', 1, NULL),
('nv22', 'quangthang', '12345', 1, NULL),
('nv03', 'hongphuc', '12345', 0, NULL),
('nv04', 'thuhuyen', '12345', 0, NULL),
('nv05', 'hoabinh', '12345', 0, NULL),
('nv06', 'vananh', '12345', 0, NULL),
('nv07', 'anhtien', '12345', 0, NULL),
('nv08', 'thinguyet', '12345', 0, NULL),
('nv09', 'trongdat', '12345', 0, NULL),
('nv10', 'huyentrang', '12345', 0, NULL),
('nv11', 'quochuy', '12345', 0, NULL),
('nv12', 'ltuananh', '12345', 0, NULL),
('nv13', 'ngocanh', '12345', 0, NULL),
('nv14', 'dieuhuong', '12345', 0, NULL),
('nv15', 'thithuong', '12345', 0, NULL),
('nv16', 'thuydung', '12345', 0, NULL),
('nv17', 'ngoclinh', '12345', 0, NULL),
('nv18', 'nhatthanh', '12345', 0, NULL),
('nv19', 'vietanh', '12345', 0, NULL),
('nv20', 'vietkhuong', '12345', 0, NULL),
('nv21', 'kimngoc', '12345', 0, NULL),
('nv22', 'hanhu', '12345', 0, NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chucvu`
--
ALTER TABLE `chucvu`
  ADD PRIMARY KEY (`MaNV`,`MaPB`,`MaCV`);

--
-- Chỉ mục cho bảng `thongtinnhanvien`
--
ALTER TABLE `thongtinnhanvien`
  ADD PRIMARY KEY (`MaNV`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`MaNV`,`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
